<?php

namespace ZfcUser\Mapper\Exception;

class InvalidArgumentException extends \InvalidArgumentException implements ExceptionInterface
{}
