<?php

namespace ZfcUser\Mapper\Exception;

class RuntimeException extends \RuntimeException implements ExceptionInterface
{}
