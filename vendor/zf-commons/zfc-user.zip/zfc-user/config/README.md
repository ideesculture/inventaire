DO NOT EDIT THE CONFIG FILES DIRECTLY IN THIS DIRECTORY!
--------------------------------------------------------

Copy the dist file into your `./config/autoload` directory. (Remove the .dist
part)
